-- Migration 010: Booking landlord notes + unified booking response RPC

ALTER TABLE public.bookings
  ADD COLUMN IF NOT EXISTS landlord_note TEXT,
  ADD COLUMN IF NOT EXISTS landlord_note_updated_at TIMESTAMPTZ;

DROP FUNCTION IF EXISTS public.transition_booking_status(UUID, TEXT);

CREATE OR REPLACE FUNCTION public.transition_booking_status(
  p_booking_id UUID,
  p_action TEXT,
  p_landlord_note TEXT DEFAULT NULL
)
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_booking public.bookings%ROWTYPE;
  v_property_owner UUID;
  v_next_status TEXT;
  v_landlord_note TEXT;
BEGIN
  SELECT b.*
  INTO v_booking
  FROM public.bookings b
  WHERE b.id = p_booking_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Booking not found';
  END IF;

  SELECT p.owner_id
  INTO v_property_owner
  FROM public.properties p
  WHERE p.id = v_booking.property_id
  FOR SHARE;

  IF p_action NOT IN ('tenant_cancel', 'landlord_confirm', 'landlord_reject', 'admin_cancel') THEN
    RAISE EXCEPTION 'Unsupported booking action';
  END IF;

  IF v_booking.status NOT IN ('pending', 'requested') THEN
    RAISE EXCEPTION 'This booking can no longer be changed manually';
  END IF;

  v_landlord_note := NULLIF(btrim(COALESCE(p_landlord_note, '')), '');

  CASE p_action
    WHEN 'tenant_cancel' THEN
      IF auth.uid() IS NULL OR auth.uid() <> v_booking.user_id THEN
        RAISE EXCEPTION 'Unauthorized booking cancellation' USING ERRCODE = '42501';
      END IF;
      v_next_status := 'cancelled';

    WHEN 'landlord_confirm' THEN
      IF auth.uid() IS NULL OR (auth.uid() <> v_property_owner AND NOT public.is_admin_user(auth.uid())) THEN
        RAISE EXCEPTION 'Unauthorized booking confirmation' USING ERRCODE = '42501';
      END IF;
      v_next_status := 'confirmed';

    WHEN 'landlord_reject' THEN
      IF auth.uid() IS NULL OR (auth.uid() <> v_property_owner AND NOT public.is_admin_user(auth.uid())) THEN
        RAISE EXCEPTION 'Unauthorized booking rejection' USING ERRCODE = '42501';
      END IF;
      v_next_status := 'rejected';

    WHEN 'admin_cancel' THEN
      IF auth.uid() IS NULL OR NOT public.is_admin_user(auth.uid()) THEN
        RAISE EXCEPTION 'Unauthorized admin cancellation' USING ERRCODE = '42501';
      END IF;
      v_next_status := 'cancelled';
  END CASE;

  UPDATE public.bookings
  SET status = v_next_status,
      confirmed_at = CASE
        WHEN v_next_status = 'confirmed' THEN COALESCE(confirmed_at, NOW())
        ELSE confirmed_at
      END,
      landlord_note = CASE
        WHEN p_action IN ('landlord_confirm', 'landlord_reject') THEN v_landlord_note
        ELSE landlord_note
      END,
      landlord_note_updated_at = CASE
        WHEN p_action IN ('landlord_confirm', 'landlord_reject') AND v_landlord_note IS NOT NULL THEN NOW()
        WHEN p_action IN ('landlord_confirm', 'landlord_reject') THEN NULL
        ELSE landlord_note_updated_at
      END,
      updated_at = NOW()
  WHERE id = p_booking_id;

  RETURN v_next_status;
EXCEPTION
  WHEN exclusion_violation THEN
    RAISE EXCEPTION 'Booking dates conflict with an existing confirmed booking'
      USING ERRCODE = '23P01';
END;
$$;

REVOKE ALL ON FUNCTION public.transition_booking_status(UUID, TEXT, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.transition_booking_status(UUID, TEXT, TEXT) TO authenticated;

NOTIFY pgrst, 'reload schema';
